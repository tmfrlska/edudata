NUM_COLS_DTYPES = ['int64', 'float64', 'datetime64[ns]']
CAT_COLS_DTYPES = ['category', 'bool', 'object']

from edudata.synthpop import Synthpop
