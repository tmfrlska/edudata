# edudata
Datasets generator for AI and Data Science Education
