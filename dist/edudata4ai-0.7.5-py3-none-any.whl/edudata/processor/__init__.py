from edudata.processor.processor import Processor
from edudata.processor.processor import NAN_KEY, NUMTOCAT_KEY
