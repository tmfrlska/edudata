NUM_COLS_DTYPES = ['int64', 'float64', 'datetime']
CAT_COLS_DTYPES = ['category', 'bool', 'object']

from edudata.synthpop import Synthpop
